using System.Xml;
using System.Xml.Schema;

namespace BIGSQUAT
{
    public class XmlValidator
    {
        private readonly string _xmlPath;
        private readonly string _xsdPath;

        public XmlValidator(string xmlPath, string xsdPath)
        {
            _xmlPath = xmlPath;
            _xsdPath = xsdPath;
        }

        // checks that XML content is valid according to XSD
        public bool ValidateXml()
        {
            bool isValid = false;
			
            XmlSchemaSet schema 
            
			XmlReaderSettings xmlReaderSettings 
            

			+= delegate (object sender, ValidationEventArgs args)
            {
                // todo : afficher l'erreur et le n° de ligne
            };
			
            XmlTextReader xmlTextReader
			
			XmlReader xmlReader 
                
			xmlReader.Read();
            
            return isValid;
        }
    }
}